

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: raw2request

short_description: Translate raw source data to normalized data format

version_added: "2.8"

description:
    - Translates source data specific formatted data to normalized data used by ONTAP playbooks
    - The format of the source data is specific to the source
    - Data is translated by a source data specific function in the module
    - The resulting, normalized data, is a standard dictionary used by all tasks after the translation

options:
    host_vars:
        description:
            - Ansible host vars for a single host.  Typically below hostvars[inventory_hostname]
        required: true
    source_var:
        description:
            - The value of this parameter specifies the variable name under hostvars[inventory_hostname]
              that specifies the source of the data.
            - Used to determine the specific translation function.
        required: false
        default:  __data_source
        supported_source_data:
            - wfa
    data_var_regex:
        description:
            - Regex used to pull raw data from hostvars.
            - The raw data is contained in 1 or more variables whose name matches data_var_regex

author:
    - Todd Urie (todd.urie@cgi.com)
'''

EXAMPLES = '''
# Translate with default values for source_var & data_var_regex
- name: Translate
  raw2request:
    host_vars:    "{{ hostvars[inventory_hostname] }}"

# Translate with non-default source variable name
- name: Translate
  raw2request:
    host_vars:    "{{ hostvars[inventory_hostname] }}"
    source_var:   'non_standard_source_var'

# Translate with non-default values for data_var_regex
- name: Translate
  raw2request:
    host_vars:    "{{ hostvars[inventory_hostname] }}"
    data_var_regex: "non_standard_[0-9]+"
'''

RETURN = '''
raw_service_request:
    description: A dictionary that contains a raw service request
    type: dict
    returned: always
    form:
      raw_service_request:
        service:      some_service
        standard:     some_standard
        operation:    create|modify|delete
        req_details:
          res_type1:
            - list of dictionaries for res_type1 definitions
          res_type2:
            - list of dictionaries for res_type2 definitions
'''

import traceback

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils._text import to_native

import time
import re

import sys
import json


################################## FUNCTIONS ############################
#---------------------------------------------------------------
# Data form specific functions
#---------------------------------------------------------------
def wfa(vars, data_var_regex):
  #--------------------------------------------------------
  # 1st we run through all the vars and capture the ones
  # of interest
  #--------------------------------------------------------
  var_names = []
  for var_name in vars.keys():
    if re.match(data_var_regex,var_name):
      var_names.append(var_name)
  
  #--------------------------------------------------------
  # Now build the raw_service_request dict
  # We sort the list of variable names in ascending order
  # because we don't know if order is significant so we
  # assume it is.
  #--------------------------------------------------------
  var_names.sort()
  raw_service_request = dict( req_details=dict() )
  for var_name in var_names:
    if re.match('res_type=req_details', vars[var_name]):
      res_type = vars[var_name].split(';')[0].split('=')[1].split('.')[1]
      val = vars[var_name].split(';')[1]
      if not res_type in raw_service_request['req_details']:
        raw_service_request['req_details'][res_type] = []
      tmp = dict( attr.split('=') for attr in val.split(',') )
      raw_service_request['req_details'][res_type].append(tmp)
    else:
      attr = vars[var_name].split(';')[1].split('=')[0]
      val = vars[var_name].split(';')[1].split('=')[1]
      raw_service_request[attr] = val

  return raw_service_request

#---------------------------------------------------------------
# Entry point
# We expect to get all variables below hostvars[CLUSTER_NAME]
#---------------------------------------------------------------
def run_module():
  argument_spec= dict(
    host_vars       = dict(type='dict', required=True),
    source_var      = dict(type='str',  default='__data_source'),
    data_var_regex  = dict(type='str',  default='req_[0-9]+')
  )

  module = AnsibleModule(
    argument_spec        = argument_spec,
    supports_check_mode  = True
  )
  parameters = module.params
  
  #----------------------------------------------
  # 1st we get the specical variable that tells
  # us what the source of the data is so we can
  # decode it.
  #----------------------------------------------
  translate = getattr(sys.modules[__name__], 
    parameters['host_vars'][parameters['source_var']],
    None)
  if translate:
    request = translate(parameters['host_vars'], parameters['data_var_regex'])
    module.exit_json(changed=True, raw_service_request=request)
  else:
    module.fail_json(failed=True, msg="data source not supported: " + parameters['source_var'])
  

################################## MAIN ############################

if __name__ == '__main__': 
   run_module()
