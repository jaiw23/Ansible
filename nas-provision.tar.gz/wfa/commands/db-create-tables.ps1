
################################################################
# FUNCTIONS
################################################################
function Get-WFAUserPassword () {
  param(
     [parameter(Mandatory=$true)]
     [string]$pw2get
  )

  $InstallDir = (Get-ItemProperty -Path HKLM:\Software\NetApp\WFA -Name WFAInstallDir).WFAInstallDir
  
  $string = Get-Content $InstallDir\jboss\bin\wfa.conf | Where-Object { $_.Contains($pw2get) }
  $mysplit = $string.split(":")
  $var = $mysplit[1]
  
  cd $InstallDir\bin\supportfiles\
  $string = echo $var | .\openssl.exe enc -aes-256-cbc -a  -d -salt -pass pass:netapp
 
  return $string
 }

################################################################
# MAIN
################################################################


Get-WfaLogger -Info -Message "Get DB Passwords"
$playground_pass  = Get-WFAUserPassword -pw2get "WFAUSER"
$mysql_pass       = Get-WFAUserPassword -pw2get "MySQL"

$lock_tbl_exists = "
  use playground;
  SHOW TABLES LIKE 'lock';
"

$lock_tbl = "
  use playground;
  CREATE TABLE ``lock`` (
    id int(11) NOT NULL AUTO_INCREMENT,
    snow_request_id varchar(255) NOT NULL,
    wfa_job_id varchar(255) NOT NULL,
    lock_state ENUM('waiting', 'active', 'released', 'expired'),
    start_time datetime NOT NULL,
    last_activity datetime NOT NULL,
    PRIMARY KEY (``id``),
    UNIQUE KEY ``uk_db_lock_natural_key`` (``snow_request_id``, ``wfa_job_id``)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8
"

$chargeback_tbl_exists = "
  use playground;
  SHOW TABLES LIKE 'chargeback';
"

$chargeback_tbl = "
  use playground;
  CREATE TABLE ``chargeback`` (
    id int(11) NOT NULL AUTO_INCREMENT,
    cluster_name varchar(255) NOT NULL,
    vserver_name varchar(255) NOT NULL,
    volume_name varchar(255) NOT NULL,
    qtree_name varchar(255) NOT NULL,
    cost_centre varchar(255) NOT NULL,
    protocol varchar(255) NOT NULL,
    storage_requirement_gb int(11) NOT NULL,
    nar_id varchar(255) NOT NULL,
    app_short_name varchar(255) NOT NULL,
    nis_domain varchar(255) NOT NULL,
    netgroup_ro varchar(255) NOT NULL,
    netgroup_rw varchar(255) NOT NULL,
    email_address varchar(255) NOT NULL,
    cluster_primary_address varchar(255) NOT NULL,
    PRIMARY KEY (``id``),
    UNIQUE KEY ``uk_db_chargeback_natural_key`` (``cluster_name``, ``vserver_name``, ``volume_name``, ``qtree_name``)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8
"

Get-WfaLogger -Info -Message "Does lock table exist?"
$result = Invoke-MySqlQuery -Query $lock_tbl_exists -user 'root' -password $mysql_pass
if ( $result[0] -eq 0 ){
  Get-WfaLogger -Info -Message "Creating the lock table"
  $result = Invoke-MySqlQuery -Query $lock_tbl -user 'root' -password $mysql_pass
}
else{
  Get-WfaLogger -Info -Message "Table already exists"
}

Get-WfaLogger -Info -Message "Does chargeback table exist?"
$result = Invoke-MySqlQuery -Query $chargeback_tbl_exists -user 'root' -password $mysql_pass
if ( $result[0] -eq 0 ){
  Get-WfaLogger -Info -Message "Creating the chargeback table"
  $result = Invoke-MySqlQuery -Query $chargeback_tbl -user 'root' -password $mysql_pass
}
else{
  Get-WfaLogger -Info -Message "Table already exists"
}

