param (
  [parameter(Mandatory=$false, HelpMessage="Contact")]
  [string]$contact,
  
  [parameter(Mandatory=$false, HelpMessage="Desired storage location")]
  [string]$location,
  
  [parameter(Mandatory=$false, HelpMessage="Cost Centre")]
  [string]$cost_centre,
  
  [parameter(Mandatory=$false, HelpMessage="environment")]
  [string]$environment,
  
  [parameter(Mandatory=$false, HelpMessage="protocol (NFS|CIFS)")]
  [string]$protocol,
  
  [parameter(Mandatory=$false)]
  [int]$storage_requirement,

  [parameter(Mandatory=$false, HelpMessage="NAR ID of app")]
  [string]$nar_id,
  
  [parameter(Mandatory=$false, HelpMessage="Application short name")]
  [string]$app_short_name,
  
  [parameter(Mandatory=$false, HelpMessage="NIS Domain")]
  [string]$nis_domain,
  
  [parameter(Mandatory=$false, HelpMessage="NIS Netgroup")]
  [string]$netgroup_ro,
  
  [parameter(Mandatory=$false, HelpMessage="NIS Netgroup")]
  [string]$netgroup_rw,
  
  [parameter(Mandatory=$false, HelpMessage="email address")]
  [string]$email_address,
  
  [parameter(Mandatory=$false, HelpMessage="service desired")]
  [string]$service,

  [parameter(Mandatory=$false)]
  [string]$snow_request_id,

  [parameter(Mandatory=$false)]
  [int]$storage_instance_count
)


########################################################################
# FUNCTIONS
########################################################################
#-----------------------------------------------------------------------
# UTILITY FUNCTIONS
#-----------------------------------------------------------------------
#-----------------------------------------------------------------
# Return value names are of the form "__raw_req_<NNN>" where NNN
# is a 3 digit number indicating sequence.  Sequence is maintained
# because it may be significant within the Execution Layer.
#-----------------------------------------------------------------
function set_wfa_return_values() {
   param(
      [parameter(Mandatory=$true, HelpMessage="placement solution")]
      [hashtable]$placement_solution
   )
   #-----------------------------------------------------------------
   # The following 2 return values are interpreted by the calling
   # Python script
   #-----------------------------------------------------------------
   Add-WfaWorkflowParameter -Name 'success'  -Value $placement_solution['success']  -AddAsReturnParameter $True
   Add-WfaWorkflowParameter -Name 'reason'   -Value $placement_solution['reason']   -AddAsReturnParameter $True
   if ( -not $placement_solution['success'] -eq "TRUE" ){
      return
   }
   #-----------------------------------------------------------------
   # The rest of the return values are all passed unmodified to the
   # Execution Layer
   #-----------------------------------------------------------------
   Add-WfaWorkflowParameter -Name 'req_source'  -Value 'wfa' -AddAsReturnParameter $True
   Add-WfaWorkflowParameter -Name 'raw_req_001' -Value $("__res_type='';std_name=" + $placement_solution['std_name']) -AddAsReturnParameter $True

   Get-WfaLogger -Info -Message $( $placement_solution['return_values'].length )
   $return_value_idx = 2
   foreach ($res_type in $placement_solution['resources'].keys ){
      Get-WfaLogger -Info -Message $res_type
      $return_value = '__res_type=' + $res_type + ';'
      foreach ( $res_attr in $placement_solution['resources'][$res_type].keys ){
         $return_value += $res_attr + '=' + $placement_solution['resources'][$res_type][$res_attr]
      }
      Add-WfaWorkflowParameter -Name $("raw_req_{0:d3}"  -f ($return_value_idx) ) -Value $return_value -AddAsReturnParameter $True
      $return_value_idx += 1
   }
}

function Get-WFAUserPassword () {
   param(
      [parameter(Mandatory=$true)]
      [string]$pw2get
   )

   $InstallDir = (Get-ItemProperty -Path HKLM:\Software\NetApp\WFA -Name WFAInstallDir).WFAInstallDir
   
   $string = Get-Content $InstallDir\jboss\bin\wfa.conf | Where-Object { $_.Contains($pw2get) }
   $mysplit = $string.split(":")
   $var = $mysplit[1]
   
   cd $InstallDir\bin\supportfiles\
   $string = echo $var | .\openssl.exe enc -aes-256-cbc -a  -d -salt -pass pass:netapp
  
   return $string
  }

function update_chargeback_table(){
   param(
      [parameter(Mandatory=$true)]
      [array]$qtrees,
      [parameter(Mandatory=$true)]
      [hashtable]$request,
      [parameter(Mandatory=$true)]
      [string]$db_user,
      [parameter(Mandatory=$true)]
      [string]$db_pw
   )

   foreach ( $qtree in $qtrees['ontap_qtree'] ){
      $new_row = "
         INSERT INTO playground.chargeback
         VALUES (
            NULL,
            '" + $qtree['name'] + "',
            '" + $qtree['vserver'] + "',
            '" + $qtree['flexvol_name']  + "',
            '" + $qtree['name']   + "',
            '" + $request['cost_centre']                                   + "',
            '" + $request['protocol']                                      + "',
            "  + $request['storage_requirement']                           + ",
            '" + $request['nar_id']                                        + "',
            '" + $request['app_short_name']                                + "',
            '" + $request['nis_domain']                                    + "',
            '" + $request['nis_netgroup']                                  + "',
            '" + $request['email_address']                                 + "',
            '" + $request['service']                                       + "',
            '" + $qtree['hostname'] + "'
         )
         ;
      "

      Invoke-MySqlQuery -query $new_row -user $db_user -password $db_pw
   }
}
#-----------------------------------------------------------------------
# STORAGE RESOURCE FUNCTIONS
#-----------------------------------------------------------------------
#-----------------------------------------------------------------------
# These items are not specifically returned by WFA as part of the
# request, but are used to build other storage resources that are
# returned as part of the request.  Therefore, we are only defining
# the objects themselves and not return values.
#-----------------------------------------------------------------------

function aggregate(){
   param(
      [parameter(Mandatory=$true)]
      [array]$vservers,
      [parameter(Mandatory=$true)]
      [string]$vol_size,
      [parameter(Mandatory=$true)]
      [string]$mysql_pw
   )

   $clusters = @()
   foreach ($vserver in $vservers){
      $clusters += $vserver['hostname']
   }
   $unique_clusters = $clusters | Sort-Object | Get-Unique
   $cluster_regex = $unique_clusters -join '|'

   #------------------------------------------------------------
   # If we want to emulate the "WFA Finder" operation, we can
   # use INNER JOIN to emulate set intersection so we can use
   # multiple criteria to define multiple return sets then take
   # only what is common among all the results.
   #------------------------------------------------------------
   $aggr_select_sql = "
      SELECT
         cluster.name         AS 'cluster_name',
         cluster.primary_address AS 'hostname',
         node.name            AS 'node_name',
         aggregate.name       AS 'name',
         aggregate.available_size_mb AS 'available_mb'
      FROM cm_storage.cluster
      JOIN cm_storage.node ON (node.cluster_id = cluster.id)
      JOIN cm_storage.aggregate ON (aggregate.node_id = node.id)
      WHERE 1
         AND cluster.primary_address REGEXP '$cluster_regex'
         AND aggregate.name NOT LIKE 'aggr0*'
      ORDER BY aggregate.available_size_mb DESC
      ;"
   Get-WfaLogger -Info -Message $("Looking for an aggr" )
   $aggrs = Invoke-MySqlQuery -query $aggr_select_sql -user root -password $mysql_pw

   if ( $aggrs[0] -ge 1 ){
      Get-WfaLogger -Info -Message $("Found aggr: " + $aggrs[1].name )
      if ( $aggrs[0] -eq 1 ){
         $return_aggr = @{
            'name'      = $aggrs[1].name;
            'hostname'  = $aggrs[1].hostname;
            'node'      = $aggrs[1].node_name
         }
      }
      else{
         $return_aggr = @{
            'name'         = $aggrs[1].name;
            'hostname'     = $aggrs[1].hostname;
            'node'         = $aggrs[1].node_name;
            'available_mb' = $aggrs[1].available_mb
         }
         foreach ( $aggr in $aggrs[2..($aggrs.count-1)] ){
            if ( $return_aggr['available_mb'] < $aggr['available_mb'] ){
               $return_aggr = @{
                  'name'         = $aggr['name'];
                  'hostname'     = $aggr['hostname'];
                  'node'         = $aggr['node_name'];
                  'available_mb' = $aggr['available_mb']
               }
            }
         }
      }
      return @{
         'success'      = $True;
         'reason'       = "Found suitable aggregate";
         'ontap_aggr'   = $return_aggr
      }
   }
   else{
      return @{
         'success'      = $False;
         'reason'       = "Failed to find aggregate with sufficient free space"
      }
   }
}

function vserver() {
   param(
      [parameter(Mandatory=$true)]
      [hashtable]$request,
      [parameter(Mandatory=$true)]
      [string]$mysql_pw
   )

   $cluster_name_regex = $request['location']                     + `
                        '[a-zA-Z]{3}NAS'                          + `
                        $cluster_service_map[$service]['prefix']  + `
                        $request['environment']                   + `
                        '[0-9]+'
   $cluster_name_regex = 'lon'
   $sql = "
      SELECT
         vserver.name            AS 'name',
         cluster.name            AS 'cluster_name',
         cluster.primary_address AS 'cluster_primary_address',
         cluster.is_metrocluster AS 'is_metrocluster'
      FROM cm_storage.cluster
      JOIN cm_storage.vserver             ON (vserver.cluster_id = cluster.id)
      WHERE 1
         AND vserver.nis_domain = '" + $request['nis_domain'] + "'
         AND cluster.name REGEXP '$cluster_name_regex'
   ;
   "

   $vservers = Invoke-MySqlQuery -Query $sql -user 'root' -password $mysql_pass

   if ($vservers[0] -ge 1 ){
      $last_idx = $vservers[0]
      foreach ( $vserver in $vservers[1..$last_idx] ){
         Get-WfaLogger -Info -Message $($vservers[1]['name'])
      }
      
      $vserver_return = @{
         'success'      = $True;
         'reason'       = "Successfully found vserver(s)";
         'ontap_vserver'   = @()
      }

      foreach ( $vserver in $vservers[1..$last_idx] ){
         Get-WfaLogger -Info -Message $("Adding vserver: " + $vserver['name'])
         $vserver_return['ontap_vserver'] += @{
            'name'         = $vserver['name'];
            'hostname'     = $vserver['cluster_primary_address'];
         }
      } 
   }
   else{
      $vserver_return = @{
         'success'      = $False;
         'reason'       = "Failed to find suitable vserver";
      }
   }
   Get-WfaLogger -Info -Message $("number of vservers: " + $vserver_return['ontap_vserver'].length)
   return $vserver_return
}
#-----------------------------------------------------------------------
# All of these storage objects are returned by WFA as part of the
# placement solution.  Also, some of them are used by other resources
# so we define both the return values and the objects themselves.
#-----------------------------------------------------------------------
function volume() {
   param(
      [parameter(Mandatory=$true)]
      [hashtable]$request,
      [parameter(Mandatory=$true)]
      [array]$vservers,
      [parameter(Mandatory=$true)]
      [hashtable]$aggregate,
      [parameter(Mandatory=$true)]
      [string]$mysql_pw
   )
   Get-WfaLogger -Info -Message "Entered volume()"
   #--------------------------------------------------------------------
   # FIXME: RTU 21 Aug 2020
   # vol_data will vary, incorporate that in the regex below
   #--------------------------------------------------------------------
   $vol_name_regex   = $vserver['name'] + '_data_' + '[0-9]{3}' + '_' + $protocol
   $qtree_name_regex = $request['service'] + '_' + $request['environment'] + '_[0-9]{5}$'
   #--------------------------------------------------------------------
   # Try to find a volume that:
   # 1.  Has the same qtrees already on it
   # 2.  The overcommit for those qtrees is less than the max
   # 3.  The useage of the volume is less than the max
   #--------------------------------------------------------------------
   $vserver_list = @()
   foreach ($vserver in $vservers){
      $vserver_list += `
         "(vserver.name = '" + $vserver['name'] + "'" + `
         " AND " + `
         "cluster.primary_address = '" + $vserver['hostname'] + "')"    
   }  
   $vserver_query = $vserver_list -join " OR "
   #-----------------------------------------------------------------
   # FIXME: RTU 14 Oct 2020
   # NETAPP-81
   # We will now support multiple qtrees so this must change
   # accordingly.  Also, this select does not take into account
   # the new qtree(s) so that needs to be fixed.
   #-----------------------------------------------------------------
   #--------------------------------------------------------------------
   # FIXME: RTU 23 Sep 2020
   # Include new share size in calcs
   #--------------------------------------------------------------------
   $total_share_size = $request['storage_instance_count'] * $request['storage_requirement']
   $vol_select = "
      SELECT
         cluster.name,
         vserver.name,
         volume.name,
         qtree.name,
         quota_rule.cluster,
         quota_rule.vserver_name,
         quota_rule.quota_volume,
         quota_rule.quota_target,
         SUM(quota_rule.disk_limit)  AS 'sum_disk_limit',
         (SUM(quota_rule.disk_limit)+$total_share_size)/(volume.size_mb*1024) AS 'overcommit'
      FROM cm_storage.cluster
      JOIN cm_storage.vserver ON ( vserver.cluster_id = cluster.id )
      JOIN cm_storage.volume ON ( volume.vserver_id = vserver.id )
      JOIN cm_storage.qtree ON (qtree.volume_id = volume.id)
      JOIN cm_storage_quota.quota_rule   ON (
         ( quota_rule.cluster = cluster.name OR quota_rule.cluster = cluster.primary_address )
         AND quota_rule.vserver_name = vserver.name
         AND quota_rule.quota_volume = volume.name
         AND CONCAT('/vol/',volume.name,'/',qtree.name) = quota_rule.quota_target
      )
      WHERE 1
         AND ( $vserver_query )
         AND qtree.name != ''
         AND qtree.name REGEXP '$qtree_name_regex'
         AND volume.used_size_mb/volume.size_mb <= $VOL_USAGE_MAX
      GROUP BY volume.name
      HAVING overcommit < $VOL_OVERCOMMIT_MAX
      ORDER BY volume.used_size_mb ASC
      ;
"

   Get-WfaLogger -Info -Message $("Querying volumes")
   $vols = invoke-MySqlQuery -query $vol_select -user root -password $mysql_pw

   $new_vol_reqd = $False
   if ($vols[0] -ge 1){
      Get-WfaLogger -Info -Message $("Found several: " + $volumes[0] )
      #----------------------------------------------------
      # We found at least 1, the 1st one in the list is the
      # least used so take that one.
      #----------------------------------------------------
      $vol_name = $vols[1].vol_name
      Get-WfaLogger -Info -Message $("selected: " + $vol_name )
   }
   elseif( $vols[0] -lt 1 ){
      $new_vol_reqd = $True
      Get-WfaLogger -Info -Message $("Found no volumes")
      #----------------------------------------------------
      # Nothing suitable it would seem.
      # 1st, find the highest existing vol idx value, then
      # increment it by 1 to for new volume name
      #----------------------------------------------------
      $vol_select = "
         SELECT
            volume.name         AS 'vol_name',
            vserver.name        AS 'vserver_name',
            cluster.name        AS 'cluster_name',
            cluster.primary_address AS 'cluster_pri_addr'
         FROM cm_storage.cluster
         JOIN cm_storage.node      ON (node.cluster_id = cluster.id)
         JOIN cm_storage.aggregate ON (aggregate.node_id = node.id)
         JOIN cm_storage.vserver   ON (vserver.cluster_id  = cluster.id)
         JOIN cm_storage.volume    ON (volume.vserver_id   = vserver.id)
         JOIN cm_storage.qtree     ON (qtree.volume_id     = volume.id)
         WHERE 1
         AND (cluster.name = '" + $aggregate['hostname'] + "' OR cluster.primary_address = '" + $aggregate['hostname'] + "')
         AND ( $vserver_query )
         AND volume.name REGEXP '$vol_name_regex'
         ORDER by volume.name DESC
         ;" 
      Get-WfaLogger -Info -Message $("Looking for highest idx for any existing vols" )
      $vols = invoke-MySqlQuery -query $vol_select -user root -password $mysql_pw
      if ( $vols[0] -ge 1 ){
         Get-WfaLogger -Info -Message $("highest idx volume: " + $vols[1].vol_name )
         Get-WfaLogger -Info -Message $("vserver: " + $vols[1].vserver_name)
         Get-WfaLogger -Info -Message $(($vols[1].vol_name -replace $($vols[1].vserver_name + "_data_"), ''))
         $old_idx                     = ($vols[1].vol_name -replace $($vols[1].vserver_name + "_data_"), '').split('_')[0]
         Get-WfaLogger -Info -Message $("old_idx=" + $old_idx )
         $new_idx       = "{0:d3}" -f ( [int]$old_idx + 1 )
         $vol_name      = $vols[1].vol_name -replace $old_idx, $new_idx
      }
      else{
         $vol_name      = $vservers[0]['name'] + '_data_001_' + $request['protocol']
      }
      Get-WfaLogger -Info -Message $("vol_name: " + $vol_name )

      $new_vol_reqd  = $True
   }

   Get-WfaLogger -Info -Message $("vol name: " + $vol_name )
   if ( $protocol -eq 'nfs' ){
      $security_style = 'unix'
   }
   else{
      $security_style = 'ntfs'
   }

   if ( $new_vol_reqd ){
      Get-WfaLogger -Info -Message ("return with new volume")
      return @{
         'success'         = $True;
         'reason'          = "successfully found suitable volume";
         # 'return_values'       = @(
         #    '__res_type=ontap_volume;'                + `
         #    'hostname='       + $vservers[0]['hostname']   + ',' + `
         #    'vserver='        + $vservers[0]['name']      + ',' + `
         #    'name='           + $vol_name             + ',' + `
         #    'junction_path='  + '/' + $vol_name       + ',' + `
         #    'security_style=' + $security_style       + ',' + `
         #    'aggregate_name=' + $aggregate['name']
         # );
         'ontap_volume'    = @{
            'hostname'     = $vservers[0]['hostname'];
            'vserver'      = $vservers[0]['name'];
            'name'         = $vol_name;
            'junction_path'   = '/' + $vol_name;
            'security_style'  = $security_style;
            'aggregate_name'  = $aggregate['name']
         }
      }
   }
   else{
      Get-WfaLogger -Info -Message ("return with found volume")
      return @{
         'success'         = $True;
         'reason'          = "successfully found suitable volume";
         #'return_values'   = @();
         # 'return_values'       = @(
         #    '__res_type=ontap_volume;'                + `
         #    'hostname='       + $vols[1].cluster_pri_addr   + ',' + `
         #    'vserver='        + $vols[1].vserver_name      + ',' + `
         #    'name='           + $vol_name             + ',' + `
         #    'junction_path='  + '/' + $vol_name       + ',' + `
         #    'security_style=' + $security_style
         # );
         'ontap_volume'    = @{
            'hostname'     = $vols[1].cluster_pri_addr;
            'vserver'      = $vols[1].vserver_name;
            'name'         = $vol_name;
            # 'junction_path'   = '/' + $vol_name;
            # 'security_style'  = $security_style;
            # 'aggregate_name'  = $aggregate['name']
         }
      }
   }
}

function qtree() {
   param(
      [parameter(Mandatory=$true)]
      [hashtable]$request,
      [parameter(Mandatory=$true)]
      [hashtable]$volume,
      [parameter(Mandatory=$true)]
      [string]$mysql_pw
   )

   $qtree_service = ($request['service'] -split ' +')[1]
   $qtree_regex = $qtree_service + '_' + $request['environment'] + '_[0-9]{' + $QTREE_NUM_DIGITS + '}$'
   #----------------------------------------------------------------------
   # RTU 21 Sep 2020
   # The naming convention for qtrees was changed as part of this work.
   # Therefore, it's very unlikely that there will be names in existence
   # when this code starts being used such that they match the pattern that
   # we are looking for.  So we are going to use the chargeback table
   # exclusively to determine qtree names.
   #
   # Also, it's possible that some downstream error could mean that a
   # qtree name found in this table actually doesn't exist.  Given the
   # maximum number of qtrees we can have with 5 digits, I don't think
   # that's a problem so I'm just going to ignore that situation.  This
   # also means it's possible that actual qtree names will have gaps in
   # numeric index values.
   #----------------------------------------------------------------------
   $qtree_select = "
      SELECT
         qtree_name  AS 'qtree_name'
      FROM playground.chargeback
      WHERE 1
         AND chargeback.cluster_primary_address = '" + $volume['hostname']  + "'
         AND chargeback.vserver_name            = '" + $volume['vserver']     + "'
         AND chargeback.volume_name             = '" + $volume['name']      + "'
         AND chargeback.qtree_name             REGEXP '$qtree_regex'
      ORDER BY qtree_name DESC
   ;
   "

   Get-WfaLogger -Info -Message "Looking for qtrees on the volume"
   $qtrees = Invoke-MySqlQuery -query $qtree_select -user root -password $mysql_pw
   #-----------------------------------------------------------------
   # FIXME: RTU 14 Oct 2020
   # NETAPP-81
   # Change this to return a list of qtrees whose numbers run in
   # sequence starting with the highest index value determined
   #-----------------------------------------------------------------
   if ( $qtrees[0] -ge 1 ){
      Get-WfaLogger -Info -Message $("Will use qtree: " + $qtrees[1].qtree_name)
      $old_idx    = ($qtrees[1].qtree_name).split('_')[2]
      $new_idx    = [int]$old_idx + 1
   }
   else{
      Get-WfaLogger -Info -Message "None, this is the 1st"
      $new_idx    = 1
      $qtree_name    = $qtree_service + '_' + $request['environment'] + '_' + $new_idx_str
   }

   $qtrees        = @()
   $return_values = @()
   for( $idx=$new_idx; $idx -lt $new_idx+$request['storage_instance_count']; $idx +=1 ){
      $new_idx_str   = "{0:d$QTREE_NUM_DIGITS}" -f ( $idx )
      $qtree_name    = $qtree_service + '_' + $request['environment'] + '_' + $new_idx_str
      Get-WfaLogger -Info -Message $("qtree_name=" + $qtree_name)
      $qtrees += @{
         'hostname'     = $volume['hostname'];
         'vserver'      = $volume['vserver'];
         'flexvol_name' = $volume['name'];
         'name'         = $qtree_name
      }
      # Get-WfaLogger -Info -Message "Set qtree return values"
      # $return_values +=                                    `
      #    '__res_type=ontap_qtree;'                 +       `
      #    'hostname='        + $volume['hostname']  + ',' + `
      #    'vserver='         + $volume['vserver']   + ',' + `
      #    'flexvol_name='    + $volume['name']      + ',' + `
      #    'name='            + $qtree_name
      # Get-WfaLogger -Info -Message "qtree return values have been set"
   }
   #-----------------------------------------------------------------
   # FIXME: RTU 14 Oct 2020
   # NETAPP-81
   # This will need to change to a list of qtrees and any code that
   # assumes a single qtree will need to change as well.
   #-----------------------------------------------------------------
   Get-WfaLogger -Info -Message $("qtrees size: " + $qtrees.length)
   Get-WfaLogger -Info -Message $("return values size: " + $return_values.length)
   return @{
      'success'         = $True;
      'reason'          = "successfully built qtree name";
      #'return_values'   = $return_values;
      'ontap_qtree'     = $qtrees
   }
}

function quota() {
   param(
      [parameter(Mandatory=$true)]
      [hashtable]$request,
      [parameter(Mandatory=$true)]
      [array]$qtrees,
      [parameter(Mandatory=$true)]
      [string]$mysql_pw
   )
   #-----------------------------------------------------------------
   # FIXME: RTU 14 Oct 2020
   # NETAPP-81
   # We will now support multiple qtrees so this must change
   # accordingly
   #-----------------------------------------------------------------
   Get-WfaLogger -Info -Message "Adding quotas to qtrees"
   $return_values = @()
   $quotas        = @()
   foreach ( $qtree in $qtrees ){
      Get-WfaLogger -Info -Message $( "Adding quotas to qtree: " + $qtree['name'])
      $quotas += @{
         'hostname'     = $qtree['hostname'];
         'vserver'      = $qtree['vserver'];
         'volume'       = $qtree['flexvol_name'];
         'quota_target' = '/vol/' + $qtree['flexvol_name'] + '/' + $qtree['name'];
         'disk_limit'   = [string]$request['storage_requirement'] + $STORAGE_REQUIREMENT_UNITS
      }
      # Get-WfaLogger -Info -Message $( "Adding return values for qtree: " + $qtree['name'])
      # $return_values += `
      #    '__res_type=ontap_quota;'                                                     + `
      #    'hostname='          + $qtree['hostname']                              + ',' + `
      #    'vserver='           + $qtree['vserver']                               + ',' + `
      #    'volume='            + $qtree['flexvol_name']                                  + ',' + `
      #    'quota_target='      + '/vol/' + $qtree['flexvol_name'] + '/' + $qtree['name'] + ',' + `
      #    'disk_limit='        + [string]$request['storage_requirement'] + $STORAGE_REQUIREMENT_UNITS
   }
   return @{
      'success'         = $True;
      'reason'          = "successfully built qtree name";
      #'return_values'   = $return_values;
      'ontap_quota'     = $quotas
   }
}

function nfs_export(){
   param(
      [parameter(Mandatory=$true)]
      [hashtable]$request,
      [parameter(Mandatory=$true)]
      [array]$qtrees,
      [parameter(Mandatory=$true)]
      [array]$volume,
      [parameter(Mandatory=$true)]
      [string]$mysql_pw
   )

   #-----------------------------------------------------------------
   # FIXME: RTU 14 Oct 2020
   # NETAPP-81
   # We will now support multiple qtrees so this must change
   # accordingly
   #-----------------------------------------------------------------
   # Return 3 items:
   # 1.  A list of export policies to provision
   # 2.  A list of rules to add to policies
   # 3.  A list of volumes/qtrees to update policy name
   $resources = @{}
   foreach ( $qtree in $qtrees ){
      $qtree_flds = $qtree['name'].split('_')
      $resources['ontap_export_policy'] += @{
         'hostname'     = $qtree['hostname'];
         'vserver'      = $qtree['vserver'];
         'name'         = $qtree['flexvol_name'] + '_' + $qtree_flds[2]
      }
      $resources['ontap_export_policy_rule'] += @{
         'hostname'              = $qtree['hostname'];
         'vserver'               = $qtree['vserver'];
         'name'                  = $qtree['flexvol_name'] + '_' + $qtree_flds[2];
         'client_match'          = '@' + $request['netgroup_ro'];
         'ro_rule'               = 'sys'
      }
      $resources['ontap_export_policy_rule'] += @{
         'hostname'     = $qtree['hostname'];
         'vserver'      = $qtree['vserver'];
         'name'         = $qtree['flexvol_name'] + '_' + $qtree_flds[2];
         'client_match' = '@' + $request['netgroup_rw'];
         'ro_rule'      = 'sys';
         'rw_rule'      = 'sys';
      }
      $qtree.Add('export_policy', $qtree['flexvol_name'] + '_' + $qtree_flds[2] )
   }

   #-----------------------------------------------------------------
   # If we have only 3 attributes for the volume, then we found an
   # existing volume and do not need to add an export policy to the
   # volume.  If there are > 3 attributes, it's a new volume, so
   # add the policy
   #-----------------------------------------------------------------
   if ( $volume.count > 3 ){
      $resources['ontap_export_policy'] += @{
         'hostname'     = $qtree['hostname'];
         'vserver'      = $qtree['vserver'];
         'name'         = $qtree['flexvol_name']
      }
      $resources['ontap_export_policy_rule'] += @{
         'hostname'              = $qtree['hostname'];
         'vserver'               = $qtree['vserver'];
         'name'                  = $qtree['flexvol_name'];
         'client_match'          = '0.0.0.0/0';
         'ro_rule'      = 'sys'
      }
   }

   $nfs_export = @{
      'success'      = $True;
      'reason'       = "Testing only";
      'resources'    = $resources
   }
   
   return $nfs_export
}
########################################################################
# VARIABLES & CONSTANTS
########################################################################
$cluster_service_map = @{
   'NAS Premium' = @{
      'prefix'    = 'M';
      'std_name'  = 'nas_premium'
   };
   'NAS Standard'    = @{
      'prefix'    =  'S';
      'std_name'  = 'nas_standard'
   };
}

$VOL_USAGE_MAX       = 0.8
$VOL_SIZE_STD        = 1
$VOL_OVERCOMMIT_MAX  = 1.3
$QTREE_NUM_DIGITS    = 5
$STORAGE_REQUIREMENT_UNITS = 'g'
########################################################################
# MAIN
########################################################################
Get-WfaLogger -Info -Message "##################### PRELIMINARIES #####################"
Get-WfaLogger -Info -Message "Get DB Passwords"
$playground_pass  = Get-WFAUserPassword -pw2get "WFAUSER"
$mysql_pass       = Get-WFAUserPassword -pw2get "MySQL"

$request = @{
   'contact'                  = $contact;
   'location'                 = $location;
   'cost_centre'              = $cost_centre;
   'environment'              = $environment;
   'protocol'                 = $protocol;
   'storage_requirement'      = $storage_requirement;
   'nar_id'                   = $nar_id;
   'app_short_name'           = $app_short_name;
   'nis_domain'               = $nis_domain;
   'netgroup_ro'              = $netgroup_ro;
   'netgroup_rw'              = $netgroup_rw;
   'email_address'            = $email_address;
   'service'                  = $service;
   'snow_request_id'          = $snow_request_id;
   'storage_instance_count'   = $storage_instance_count;
}
#---------------------------------------------------------------
# The placement solution maintains both the return values and
# what amounts to an object definition.  The return values are
# taken unchanged and passed as WFA workflow return values.
# The objects are maintained because some are used in order to
# fully define other objects.
#---------------------------------------------------------------
#---------------------------------------------------------------
# NETAPP-70
# Get our current state from the db.lock table.  If we have timed
# out, we bail at this point.
# Set success to FALSE and reason as TIMEDOUT waiting for lock
#---------------------------------------------------------------
$wfa_job_id = Get-WfaRestParameter -Name jobId
$sql = "
  SELECT
    snow_request_id   AS 'snow_request_id',
    wfa_job_id        AS 'wfa_job_id',
    lock_state        AS 'lock_state',
    start_time        AS 'start_time',
    last_activity     AS 'last_activity'
  FROM playground.lock
  WHERE 1
    AND snow_request_id = '$snow_request_id'
    AND wfa_job_id = '$wfa_job_id'
  ORDER BY start_time ASC;
"
$result = Invoke-MySqlQuery -Query $sql -user 'root' -password $mysql_pass
if ( $result[0] -ne 1 ){
   $fail_msg = 'Unable to obtain required workflow lock'
   Get-WfaLogger -Info -Message $($fail_msg)
   $placement_solution['success']   = 'FALSE'
   $placement_solution['reason']    = $fail_msg
   set_wfa_return_values $placement_solution
   exit
}
elseif ( $result[1].lock_state -ne 'active' ){
   $fail_msg = 'Timed out trying to acquire execution lock'
   Get-WfaLogger -Info -Message $($fail_msg)
   $placement_solution['success']   = 'FALSE'
   $placement_solution['reason']    = $fail_msg
   set_wfa_return_values $placement_solution
   exit
}

$placement_solution = @{
   'success'         = 'TRUE';
   'reason'          = 'successfully determined a placement solution';
   'std_name'        = '';
   'resources'       = @{};
   'return_values'   = @();
}

#---------------------------------------------------------------
# If we don't have a mapping for the service we must bail
#---------------------------------------------------------------
Get-WfaLogger -Info -Message "Check requested service against supported services"
if ( -not $cluster_service_map.ContainsKey($service) ){
   $fail_msg = 'unsupported service requested: ' + $service
   Get-WfaLogger -Info -Message $($fail_msg)
   $placement_solution['success']   = 'FALSE'
   $placement_solution['reason']    = $fail_msg
   set_wfa_return_values $placement_solution
   exit
}

$placement_solution['std_name']  = $cluster_service_map[$service]['std_name']

#---------------------------------------------------------------
# Get the vserver that matches the NIS Domain
#---------------------------------------------------------------
Get-WfaLogger -Info -Message "##################### VSERVERS #####################"
$vserver = vserver `
         -request $request `
         -mysql_pw $mysql_pass 
if ( -not $vserver['success'] ){
   $fail_msg = $vserver['reason'] + ": nis_domain=" + $request['nis_domain']
   Get-WfaLogger -Info -Message $fail_msg
   $placement_solution['success']   = 'FALSE'
   $placement_solution['reason']    = $fail_msg
   set_wfa_return_values $placement_solution
   exit
}
#$placement_solution['resources']['ontap_vserver'] = $vserver['ontap_vserver']

#---------------------------------------------------------------
# Get an aggregate in case we need a new volume.  We could do
# this after we determine whether or not we need a new volume,
# but this is not that expensive to do it here and just makes
# things a bit easier IMHO.
#---------------------------------------------------------------
Get-WfaLogger -Info -Message "##################### AGGR #####################"
Get-WfaLogger -Info -Message "Find an aggr"
$aggr = aggregate                               `
      -vservers      $vserver['ontap_vserver']  `
      -vol_size      $VOL_SIZE_STD              `
      -mysql_pw      $mysql_pass
if ( -not $aggr['success'] ){
   $fail_msg = $aggr['reason']
   Get-WfaLogger -Info -Message $fail_msg
   $placement_solution['success']   = 'FALSE'
   $placement_solution['reason']    = $fail_msg
   set_wfa_return_values $placement_solution
   exit
}

Get-WfaLogger -Info -Message "##################### VOLUME #####################"
$volume = volume `
      -vservers $vserver['ontap_vserver'] `
      -aggregate $aggr['ontap_aggr'] `
      -request $request `
      -mysql_pw $mysql_pass
if ( -not $volume['success'] ){
   $fail_msg = $volume['reason']
   Get-WfaLogger -Info -Message $fail_msg
   $placement_solution['success']   = 'FALSE'
   $placement_solution['reason']    = $fail_msg
   set_wfa_return_values $placement_solution
   exit
}

#$placement_solution['resources']['ontap_volume'] = $volume['ontap_volume']
#$placement_solution['return_values'] += $volume['return_values']

Get-WfaLogger -Info -Message "##################### QTREE NAME #####################"

$qtrees = qtree  `
   -request    $request  `
   -volume     $volume['ontap_volume']       `
   -mysql_pw   $mysql_pass
if ( -not $qtrees['success'] ){
   $fail_msg = $qtrees['reason']
   Get-WfaLogger -Info -Message $fail_msg
   $placement_solution['success']   = 'FALSE'
   $placement_solution['reason']    = $fail_msg
   set_wfa_return_values $placement_solution
   exit

$placement_solution['resources']['ontap_qtree'] = $qtrees['ontap_qtree']
#$placement_solution['return_values'] += $qtrees['return_values']

Get-WfaLogger -Info -Message "##################### QUOTA RULE #####################"
$quota = quota  `
   -request    $request                      `
   -qtrees     $qtrees['ontap_qtree']       `
   -mysql_pw   $mysql_pass
if ( -not $quota['success'] ){
   $fail_msg = $quota['reason']
   Get-WfaLogger -Info -Message $fail_msg
   $placement_solution['success']   = 'FALSE'
   $placement_solution['reason']    = $fail_msg
   set_wfa_return_values $placement_solution
   exit
}
$placement_solution['resources']['ontap_quota'] = $quota['ontap_quota']
#$placement_solution['return_values'] += $quota['return_values']

Get-WfaLogger -Info -Message "##################### NFS EXPORT #####################"
$nfs_export = nfs_export `
   -request  $request                  `
   -qtrees   $qtrees['ontap_qtree']     `
   -volume   $volume['ontap_volume']    `
   -mysql_pw      $mysql_pass
if ( -not $nfs_export['success'] ){
   $fail_msg = $nfs_export['reason']
   Get-WfaLogger -Info -Message $fail_msg
   $placement_solution['success']   = 'FALSE'
   $placement_solution['reason']    = $fail_msg
   set_wfa_return_values $placement_solution
   exit
}

foreach ( $res_type in $nfs_export['resources'].keys ){
   $placement_solution['resources'][$res_type]        = $nfs_export[$res_type]
}


#---------------------------------------------------------------
# Everything was successful so consolidate and finish up
#---------------------------------------------------------------
#---------------------------------------------------------------
# FIXME: RTU 15 Oct 2020
# NETAPP-70
# update the chargeback table
# Update our lock record to complete if it's still showing
# active.
# Check that it is now complete.
# If it's not complete,
#     set success to FAIL
#     reason to lock expired
# set return values
#---------------------------------------------------------------
Get-WfaLogger -Info -Message "##################### CHARGEBACK TABLE #####################"
update_chargeback_table `
   -qtrees $qtrees['ontap_qtree'] `
   -request $request `
   -db_user 'root' `
   -db_pw $mysql_pass

$lock_date = Get-Date -f 'yyyy-MM-dd HH:mm:ss'
$sql = "
   LOCK TABLES playground.lock WRITE;
   UPDATE playground.lock SET lock_state = 'released', last_activity = '$lock_date';
   UNLOCK TABLES;
"
$result = Invoke-MySqlQuery -Query $sql -user 'root' -password $mysql_pass

if ( $result[1].lock_state -eq 'timedout' ){
   $fail_msg = 'Failed to release execution lock'
   Get-WfaLogger -Info -Message $($fail_msg)
   $placement_solution['success']   = 'FALSE'
   $placement_solution['reason']    = $fail_msg
   set_wfa_return_values $placement_solution
   exit
}
Get-WfaLogger -Info -Message "##################### RETURN VALUES #####################"
set_wfa_return_values -placement_solution $placement_solution

